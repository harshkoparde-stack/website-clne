<base href="/">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>DubaiExchange - Exchange</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        :root { 
            --primary-color: #6c5ce7;
            --secondary-color: #a29bfe;
            --dark-color: #2d3436;
            --light-color: #f5f6fa;
        }
       
        /* Top Header Styles */
        .top-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 8px 40px;
            color: white;
        }
        
        .availability-text {
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .availability-text i {
    color: #00b894;
    animation: blink 1s step-start infinite;
}

@keyframes blink {
    50% {
        opacity: 0;
    }
}
        
        .auth-buttons .btn {
            border-radius: 20px;
            padding: 6px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .auth-buttons .btn-login {
            background-color: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.4);
            color: white;
        }
        
        .auth-buttons .btn-signup {
            background-color: white;
            color: var(--primary-color);
        }
        
        .auth-buttons .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .auth-buttons .btn:active {
            transform: translateY(0);
        }
        
        .auth-buttons .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }
        
        .auth-buttons .btn:hover::before {
            left: 100%;
        }
        
        /* Main Header Styles */
        .main-header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding-left: 20px;
        }
        
        .logo {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(to right, var(--primary-color) 50%, var(--dark-color) 50%);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            transition: all 0.3s ease;
        }
        
        .logo:hover {
            transform: scale(1.05);
        }
        
        .nav-link {
            color: var(--dark-color);
            font-weight: 500;
            position: relative;
            padding: 8px 15px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background-color: var(--primary-color);
            transition: width 0.3s ease;
        }
        
        .nav-link:hover::after {
            width: 70%;
        }
        
        /* User Dropdown Styles */
        .user-dropdown .dropdown-toggle {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--dark-color);
            font-weight: 500;
        }
        
        .user-dropdown .dropdown-toggle::after {
            margin-left: 8px;
        }
        
        .user-dropdown .dropdown-menu {
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .user-dropdown .dropdown-item {
            padding: 10px 15px;
            transition: all 0.2s ease;
        }
        
        .user-dropdown .dropdown-item:hover {
            background-color: var(--secondary-color);
            color: white;
            padding-left: 20px;
        }
        
        /* Mobile Menu */
        .navbar-toggler {
            border: none;
            padding: 8px;
        }
        
        .navbar-toggler:focus {
            box-shadow: none;
        }
        
        .navbar-toggler-icon {
            background-image: none;
            position: relative;
            width: 24px;
            height: 2px;
            background-color: var(--dark-color);
            transition: all 0.3s ease;
        }
        
        .navbar-toggler-icon::before,
        .navbar-toggler-icon::after {
            content: '';
            position: absolute;
            width: 24px;
            height: 2px;
            background-color: var(--dark-color);
            left: 0;
            transition: all 0.3s ease;
        }
        
        .navbar-toggler-icon::before {
            transform: translateY(-8px);
        }
        
        .navbar-toggler-icon::after {
            transform: translateY(8px);
        }
        
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon {
            background-color: transparent;
        }
        
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon::before {
            transform: rotate(45deg);
        }
        
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon::after {
            transform: rotate(-45deg);
        }
        
        /* Mobile Auth Buttons */
        .mobile-auth-buttons {
            display: none;
            padding: 15px 0;
        }
        
        .mobile-auth-buttons .btn {
            border-radius: 20px;
            padding: 8px 20px;
            font-weight: 500;
            margin: 5px 0;
            width: auto;
            display: inline-block;
        }
        
        .mobile-auth-buttons .btn-login {
            background-color: rgba(108, 92, 231, 0.2);
            border: 1px solid rgba(108, 92, 231, 0.4);
            color: var(--primary-color);
        }
        
        .mobile-auth-buttons .btn-signup {
            background-color: var(--primary-color);
            color: white;
        }
        
        .mobile-auth-container {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        /* Mobile User Dropdown */
        .mobile-user-dropdown .dropdown-toggle {
            width: 100%;
            text-align: left;
            background-color: var(--light-color);
            border: none;
            color: var(--dark-color);
            padding: 10px 15px;
            border-radius: 8px;
        }
        
        /* Animations */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .auth-buttons {
                display: none;
            }
            
            .mobile-auth-buttons {
                display: block;
            }
            
            .availability-text {
                padding-top: 12px;
            }
            
            .nav-item {
                margin: 5px 0;
            }
            
            .navbar-nav {
                padding-bottom: 15px;
                border-bottom: 1px solid rgba(0,0,0,0.1);
            }
            .availability-text{
                padding:4px !important;
            }
            .navbar-brand{
                font-size:1.5rem !important;
            }
        }
    </style>
</head>
<body>
    <!-- Top Header Section -->
    <div class="top-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="availability-text animate__animated animate__fadeIn">
                        <i class="fas fa-circle"></i> 24/7 Available
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="auth-buttons">
                                                    <a href="auth/login.php" class="btn btn-login me-2 animate__animated animate__fadeInRight">Login</a>
                            <a href="auth/signup.php" class="btn btn-signup animate__animated animate__fadeInRight">Sign Up</a>
                                            </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Header Section -->
    <header class="main-header">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand logo" href="index.php">DUBAIEXCHANGE</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <div class="mobile-auth-buttons">
                                                    <div class="mobile-auth-container">
                                <a href="auth/login.php" class="btn btn-login animate__animated animate__fadeInRight">Login</a>
                                                            <a href="auth/signup.php" class="btn btn-signup animate__animated animate__fadeInRight">Sign Up</a>

                            </div>
                                            </div>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Exchange</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="deposit.php">Deposit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rates.php">Rates</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonial.php">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="news.php">News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                    
                    <!-- Mobile Auth Buttons -->
                    
                </div>
            </nav>
        </div>
    </header>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation to nav items on page load
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach((item, index) => {
                item.style.animation = `fadeInDown 0.5s ease forwards ${index * 0.1}s`;
            });
            
            // Add ripple effect to buttons
            const buttons = document.querySelectorAll('.btn');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const x = e.clientX - e.target.getBoundingClientRect().left;
                    const y = e.clientY - e.target.getBoundingClientRect().top;
                    
                    const ripple = document.createElement('span');
                    ripple.className = 'ripple';
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    
                    this.appendChild(ripple);
                    
                    setTimeout(() => {
                        ripple.remove();
                    }, 1000);
                });
            });
        });
    </script>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>WhatsApp Button</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .whatsapp-float {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: rgba(201, 255, 200, 0.3);
            color: #25d366;
            border-radius: 30px;
            padding: 8px 15px;
            font-size: 16px;
            box-shadow: 2px 2px 8px rgba(0,0,0,0.3);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: transform 0.2s ease-in-out, background-color 0.3s;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-weight: bold;
        }

        .whatsapp-float i {
            font-size: 30px;
        }

        .whatsapp-float:hover {
            background-color: rgba(37, 211, 102, 0.3);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <!-- WhatsApp Floating Button -->
    <a href="https://wa.me/+918516885685?text=Hello+i+Need+USDT" 
       target="_blank" 
       class="whatsapp-float" 
       id="whatsappButton">
        <i class="fab fa-whatsapp"></i>
        <span class="help-text">Need Help?</span>
    </a>

    <script>
    // Function to update the WhatsApp number every minute
    function updateWhatsAppNumber() {
        fetch('get_whatsapp_number.php')
            .then(response => response.json())
            .then(data => {
                if (data.number) {
                    const whatsappButton = document.getElementById('whatsappButton');
                    whatsappButton.href = `https://wa.me/${data.number}?text=${encodeURIComponent('Hello i Need USDT')}`;
                }
            })
            .catch(error => console.error('Error fetching WhatsApp number:', error));
    }

    // Update immediately and then every minute
    updateWhatsAppNumber();
    setInterval(updateWhatsAppNumber, 60000); // 60,000 ms = 1 minute
    </script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"9cb5e453abb04bcaa0059d78bd938d1d","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MXWNJKWL0C"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MXWNJKWL0C');
</script>



<main class="exchange-main">
    <div class="container">
        <!-- Hero Section -->
        <section class="hero-section text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">DubaiExchange</h1>
            <p class="hero-subtitle animate__animated animate__fadeIn animate__delay-1s">Fast, Secure Currency Exchange</p>

                    </section>

        <!-- Exchange Widget -->
        <section class="exchange-widget-section">
            <div class="exchange-widget-container">
                <form id="exchangeForm" method="post">
                    <div class="exchange-cards-container">
                        <!-- Send Currency Card -->
<div class="currency-card send-card">
    <div class="card-header">
        <span class="badge">You Send</span>
        <div class="card-icon">
            <i class="fas fa-arrow-up"></i>
        </div>
    </div>
    <div class="card-body">
        <div class="form-group">
            <div class="currency-select-wrapper">
                <div class="currency-flag" id="sendFlag"></div>
                <select class="form-select" name="send_currency" id="sendCurrency" required>
    <option value="">Select Currency</option>
            <option value="USDT" 
            >
            USDT        </option>
            <option value="INR" 
            selected>
            INR        </option>
    </select>
            </div>
        </div>
        <div class="amount-input-group">
            <span class="input-icon"><i class="fas fa-money-bill-wave"></i></span>
            <input type="text" class="form-control" placeholder="Amount" disabled>
            <span class="currency-display">0.00</span>
        </div>
        <div class="amount-limits">
            <span class="min-amount-from">--</span>
            <span class="max-amount-from">--</span>
        </div>
    </div>
</div>
                        <!-- Swap Button -->
                        <div class="swap-container">
                            <button type="button" class="swap-btn" id="swapCurrencies">
                                <i class="fas fa-exchange-alt"></i>
                            </button>
                            <div class="exchange-rate-display">--</div>
                        </div>

                        <!-- Receive Currency Card -->
<div class="currency-card receive-card">
    <div class="card-header">
        <span class="badge">You Receive</span>
        <div class="card-icon">
            <i class="fas fa-arrow-down"></i>
        </div>
    </div>
    <div class="card-body">
        <div class="form-group">
            <div class="currency-select-wrapper">
                <div class="currency-flag" id="receiveFlag"></div>
               <select class="form-select" name="receive_currency" id="receiveCurrency" required>
    <option value="">Select Currency</option>
            <option value="INR" 
            >
            INR        </option>
            <option value="USDT" 
            selected>
            USDT        </option>
    </select>
            </div>
        </div>
        <div class="amount-input-group">
            <span class="input-icon"><i class="fas fa-wallet"></i></span>
            <input type="text" class="form-control" placeholder="Amount" disabled>
            <span class="currency-display">0.00</span>
        </div>
        <div class="amount-limits">
            <span class="min-amount-to">--</span>
            <span class="max-amount-to">--</span>
        </div>
    </div>
</div>
</div>

                    <!-- Exchange Summary -->
                    <div class="exchange-summary">
                        <div class="summary-content">
                            <div class="delivery-info">
                                <i class="fas fa-info-circle"></i>
                                <div>
                                    <p>Estimated delivery</p>
                                    <span>Within 10 minutes</span>
                                </div>
                            </div>
                            <button type="submit" class="btn-continue">
                                <i class="fas fa-arrow-right"></i> Continue
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- Features Grid -->
        <section class="features-section">
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Bank-Level Security</h3>
                    <p>Your funds and data are protected with enterprise-grade encryption.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>24/7 Support</h3>
                    <p>Our expert team is always available to assist with your exchange.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-user-friends"></i>
                    </div>
                    <h3>Live Agents Online</h3>
                    <p><span id="agentsOnline">24</span> agents available now for instant support.</p>
                    <div class="progress-bar">
                        <div class="progress"></div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Recent Transactions -->
        <section class="transactions-section">
            <div class="transactions-card">
                <div class="transactions-header">
                    <h3><i class="fas fa-exchange-alt"></i> Recent Transactions</h3>
                </div>
                <div class="transactions-body">
                    <table class="transactions-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Sent</th>
                                <th>Received</th>
                                <th>Status</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody id="recentTransactions">
                            <!-- Transactions will be loaded here by JavaScript -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const exchangeRates = [{"from_currency":"USDT","to_currency":"INR","rate":"90.0000000","min_amount":"35.00","max_amount":"20000.00"},{"from_currency":"INR","to_currency":"USDT","rate":"0.0114900","min_amount":"2175.00","max_amount":"10000000.00"}];
    const sendCurrency = document.getElementById('sendCurrency');
    const receiveCurrency = document.getElementById('receiveCurrency');

    // Alag spans for From aur To
    const minFromSpan = document.querySelector('.min-amount-from');
    const maxFromSpan = document.querySelector('.max-amount-from');
    const minToSpan = document.querySelector('.min-amount-to');
    const maxToSpan = document.querySelector('.max-amount-to');

    const rateSpan = document.querySelector('.exchange-rate-display');
    const sendFlag = document.getElementById('sendFlag');
    const receiveFlag = document.getElementById('receiveFlag');

function updateRateInfo() {
    const fromCurr = sendCurrency.value;
    const toCurr = receiveCurrency.value;

    if (fromCurr && toCurr) {
        let rateInfo = exchangeRates.find(rate =>
            rate.from_currency === fromCurr &&
            rate.to_currency === toCurr
        );

        if (rateInfo) {
            // From currency min/max from DB
            minFromSpan.textContent = formatCurrency(rateInfo.min_amount) + ' ' + fromCurr;
            maxFromSpan.textContent = formatCurrency(rateInfo.max_amount) + ' ' + fromCurr;

            // To currency min/max -> amount * rate from DB
            const minTo = rateInfo.min_amount * rateInfo.rate;
            const maxTo = rateInfo.max_amount * rateInfo.rate;
            minToSpan.textContent = formatCurrency(minTo) + ' ' + toCurr;
            maxToSpan.textContent = formatCurrency(maxTo) + ' ' + toCurr;

            // ✅ Fixed exchange rate display logic
            let formattedRate;
            let rateDisplayText;
            
            if (fromCurr === "INR" && toCurr === "USDT") {
                formattedRate = 87; // dummy value
                rateDisplayText = `1 USDT = ${formattedRate} INR`;
            } else {
                formattedRate = parseFloat(rateInfo.rate).toFixed(3); // DB value
                rateDisplayText = `1 ${fromCurr} = ${formattedRate} ${toCurr}`;
            }

            // Exchange rate show karna
            rateSpan.textContent = rateDisplayText;
        } else {
            minFromSpan.textContent = '--';
            maxFromSpan.textContent = '--';
            minToSpan.textContent = '--';
            maxToSpan.textContent = '--';
            rateSpan.textContent = '--';
        }
    } else {
        minFromSpan.textContent = '--';
        maxFromSpan.textContent = '--';
        minToSpan.textContent = '--';
        maxToSpan.textContent = '--';
        rateSpan.textContent = '--';
    }
}
    function formatCurrency(amount) {
        return new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 0,
            minimumFractionDigits: 0
        }).format(amount);
    }

    function updateFlag(selectElement, flagElement) {
        const currencyCode = selectElement.value;
        if (currencyCode) {
            flagElement.style.backgroundImage = `url('/assets/${currencyCode}.png')`;
            flagElement.style.display = 'block';
        } else {
            flagElement.style.display = 'none';
        }
    }

    // Receive options update logic
    sendCurrency.addEventListener('change', function() {
        const sendCurrencyValue = this.value;
        const receiveSelect = document.getElementById('receiveCurrency');
        const previouslySelected = receiveSelect.value;

        while (receiveSelect.options.length > 1) {
            receiveSelect.remove(1);
        }

                    if ("USDT" === sendCurrencyValue) {
                const option = document.createElement('option');
                option.value = "INR";
                option.textContent = "INR";
                
                // Try to preserve USDT selection if available
                if ("INR" === 'USDT') {
                    option.selected = true;
                }
                
                receiveSelect.appendChild(option);
            }
                    if ("INR" === sendCurrencyValue) {
                const option = document.createElement('option');
                option.value = "USDT";
                option.textContent = "USDT";
                
                // Try to preserve USDT selection if available
                if ("USDT" === 'USDT') {
                    option.selected = true;
                }
                
                receiveSelect.appendChild(option);
            }
                
        // If USDT is not available, select the first option
        if (receiveSelect.value === "" && receiveSelect.options.length > 1) {
            receiveSelect.selectedIndex = 1;
        }
        
        // Update flags and rate info
        updateFlag(sendCurrency, sendFlag);
        updateFlag(receiveCurrency, receiveFlag);
        updateRateInfo();
    });

    // Update flags when receive currency changes
    receiveCurrency.addEventListener('change', function() {
        updateFlag(receiveCurrency, receiveFlag);
        updateRateInfo();
    });

    

    // Initialize currencies with INR to USDT
    function initializeCurrencies() {
        // Set INR as default for send
        for (let i = 0; i < sendCurrency.options.length; i++) {
            if (sendCurrency.options[i].value === 'INR') {
                sendCurrency.selectedIndex = i;
                break;
            }
        }
        
        // Update receive options based on INR selection
        const receiveSelect = document.getElementById('receiveCurrency');
        while (receiveSelect.options.length > 1) {
            receiveSelect.remove(1);
        }

                    if ("USDT" === 'INR') {
                const option = document.createElement('option');
                option.value = "INR";
                option.textContent = "INR";
                
                // Select USDT by default
                if ("INR" === 'USDT') {
                    option.selected = true;
                }
                
                receiveSelect.appendChild(option);
            }
                    if ("INR" === 'INR') {
                const option = document.createElement('option');
                option.value = "USDT";
                option.textContent = "USDT";
                
                // Select USDT by default
                if ("USDT" === 'USDT') {
                    option.selected = true;
                }
                
                receiveSelect.appendChild(option);
            }
                
        // Update flags and rate info
        updateFlag(sendCurrency, sendFlag);
        updateFlag(receiveCurrency, receiveFlag);
        updateRateInfo();
    }
    
    // Run initialization
    initializeCurrencies();
});
</script>

<script>
// Recent transactions script (same as before)
document.addEventListener('DOMContentLoaded', async function () {
    const response = await fetch("get_transactions.php");
    const data = await response.json();

    const adminRateUSDT = parseFloat(data.rate.usdt_inr);
    const adminRateINR = parseFloat(data.rate.inr_usdt);

    const indianNames = [
        "Aarav Patel", "Diya Sharma", "Vihaan Singh", "Ananya Gupta", "Reyansh Kumar",
        "Isha Reddy", "Arjun Mehta", "Saanvi Joshi", "Aditya Malhotra", "Kiara Iyer",
        "Kabir Chatterjee", "Myra Banerjee", "Vivaan Choudhury", "Anika Desai", "Ayaan Trivedi",
        "Pari Nair", "Rudra Saxena", "Amaira Khanna", "Atharva Kapoor", "Zara Oberoi"
    ];
    const currencies = ['INR', 'USDT'];
    let usedNames = new Set();

    // Generate fake transactions
    function generateFakeTransactions(count) {
        const txs = [];
        for (let i = 0; i < count; i++) {
            let name;
            do {
                name = indianNames[Math.floor(Math.random() * indianNames.length)];
            } while (usedNames.has(name) && usedNames.size < indianNames.length);
            usedNames.add(name);

            const fromCurrency = currencies[Math.floor(Math.random() * currencies.length)];
            const toCurrency = fromCurrency === "USDT" ? "INR" : "USDT";

            // Amount with min & max
            let amountSent;
            if (fromCurrency === "USDT") {
                amountSent = (500 + Math.random() * (800 - 500)).toFixed(2);
            } else {
                amountSent = (5000 + Math.random() * (12000 - 5000)).toFixed(2);
            }

            let amountReceived;
            if (fromCurrency === "USDT") {
                amountReceived = (amountSent * adminRateUSDT).toFixed(2);
            } else {
                amountReceived = (amountSent * adminRateINR).toFixed(2);
            }

            // Time
            const minutesAgo = Math.floor(Math.random() * 120);
            let timeText;
            if (minutesAgo < 1) timeText = "Just now";
            else if (minutesAgo < 60) timeText = `${minutesAgo} min${minutesAgo > 1 ? "s" : ""} ago`;
            else timeText = `${Math.floor(minutesAgo / 60)} hr${Math.floor(minutesAgo / 60) > 1 ? "s" : ""} ago`;

            const status = Math.random() > 0.2 ? "Completed" : "Pending";

            txs.push({
                type: "fake",
                name: name,
                sent: `${parseFloat(amountSent).toLocaleString("en-IN")} ${fromCurrency}`,
                received: `${parseFloat(amountReceived).toLocaleString("en-IN")} ${toCurrency}`,
                status: status,
                time: timeText,
                minutesAgo: minutesAgo
            });
        }
        return txs;
    }

    // Display transactions
    function displayTransactions(transactions) {
        const tbody = document.getElementById("recentTransactions");
        tbody.innerHTML = "";
        transactions.forEach((tx) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${tx.name}</td>
                <td>${tx.sent}</td>
                <td>${tx.received}</td>
                <td>
                    <span class="status-badge ${tx.status.toLowerCase() === "completed" ? "completed" : "pending"}">
                        ${tx.status}
                    </span>
                </td>
                <td>${tx.time}</td>
            `;
            tbody.appendChild(row);
        });
    }

    // Sort by time latest first
    function sortTransactions(transactions) {
        return transactions.sort((a, b) => a.minutesAgo - b.minutesAgo);
    }

    // Initial Transactions
    let fakeTransactions = generateFakeTransactions(20);
    let allTransactions = sortTransactions([...data.realOrders, ...fakeTransactions]);

    // Initial Display
    displayTransactions(allTransactions.slice(0, 10));

    // Rotate after 20 sec
    setInterval(() => {
        // Keep first 5, replace last 5
        const keepCount = 5;
        const newCount = 5;

        // Old first 5 remain, remove used names of replaced transactions
        const oldPart = allTransactions.slice(0, keepCount);
        allTransactions.slice(keepCount).forEach(tx => {
            if (tx.type === "fake") usedNames.delete(tx.name);
        });

        // Generate new transactions for replaced part
        const newPart = generateFakeTransactions(newCount);

        // Merge again
        allTransactions = sortTransactions([...oldPart, ...newPart]);
        displayTransactions(allTransactions.slice(0, 10));

    }, 50000);
});
</script>


<style>
/* CSS Variables for consistent theming */
:root {
    --primary: #6c5ce7;
    --primary-dark: #5649c9;
    --secondary: #00b894;
    --accent: #fd79a8;
    --light: #f8f9fa;
    --dark: #343a40;
    --gray: #6c757d;
    --light-gray: #e9ecef;
    --white: #ffffff;
    --success: #28a745;
    --warning: #ffc107;
    --danger: #dc3545;
    --border-radius: 12px;
    --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    --transition: all 0.3s ease;
}

/* Base Styles */
.exchange-main {
    padding: 2rem 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fafafa;
    min-height: 100vh;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
}

/* Hero Section */
.hero-section {
    margin-bottom: 3rem;
}

.hero-title {
    font-size: 3rem;
    font-weight: 800;
    color: var(--primary);
    margin-bottom: 0.5rem;
}

.hero-subtitle {
    font-size: 1.2rem;
    color: var(--gray);
    margin-bottom: 2rem;
}

.alert {
    padding: 1rem 1.5rem;
    border-radius: var(--border-radius);
    margin: 1rem auto;
    max-width: 600px;
}

.alert-danger {
    background-color: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.2);
    color: var(--danger);
}

/* Exchange Widget */
.exchange-widget-section {
    margin-bottom: 4rem;
}

.exchange-widget-container {
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
    padding: 2rem;
    margin-bottom: 2rem;
    transition: var(--transition);
}

.exchange-widget-container.form-error {
    animation: shake 0.5s;
    border: 1px solid rgba(220, 53, 69, 0.2);
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
    20%, 40%, 60%, 80% { transform: translateX(5px); }
}

.exchange-cards-container {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
    justify-content: space-between;
    margin-bottom: 2rem;
}

.currency-card {
    flex: 1;
    min-width: 280px;
    background: var(--white);
    border-radius: var(--border-radius);
    padding: 1.5rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    transition: var(--transition);
    border-top: 4px solid transparent;
}
.currency-select-wrapper {
    position: relative;
    display: flex;
    align-items: center;
}

.currency-flag {
    width: 24px;
    height: 18px;
    position: absolute;
    left: 12px;
    background-size: cover;
    background-position: center;
    z-index: 2;
}

.form-select {
    padding-left: 40px !important;
}

.send-card {
    border-top-color: var(--primary);
}

.receive-card {
    border-top-color: var(--secondary);
}

.currency-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.badge {
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.85rem;
}

.send-card .badge {
    background-color: rgba(108, 92, 231, 0.1);
    color: var(--primary);
}

.receive-card .badge {
    background-color: rgba(0, 184, 148, 0.1);
    color: var(--secondary);
}

.card-icon {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(108, 92, 231, 0.1);
    color: var(--primary);
}

.receive-card .card-icon {
    background-color: rgba(0, 184, 148, 0.1);
    color: var(--secondary);
}

.card-body {
    display: flex;
    flex-direction: column;
    gap: 1.2rem;
}

.form-group {
    margin-bottom: 0;
}

.form-select {
    width: 100%;
    padding: 0.875rem 1rem;
    border: 1px solid var(--light-gray);
    border-radius: 8px;
    font-size: 1rem;
    background-color: var(--white);
    transition: var(--transition);
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%236c757d' viewBox='0 0 16 16'%3E%3Cpath d='M8 12L2 6h12L8 12z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 1rem center;
    background-size: 16px;
}

.form-select:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 0.2rem rgba(108, 92, 231, 0.25);
    outline: none;
}

.form-select.input-error {
    border-color: var(--danger);
}

.amount-input-group {
    position: relative;
    display: flex;
    align-items: center;
}

.input-icon {
    position: absolute;
    left: 1rem;
    color: var(--gray);
    z-index: 2;
}

.amount-input-group .form-control {
    padding-left: 3rem;
    padding-right: 4.5rem;
    height: 54px;
    border: 1px solid var(--light-gray);
    border-radius: 8px;
    font-size: 1rem;
    background-color: var(--light);
    color: #000;
}

.amount-input-group .form-control:disabled {
    background-color: var(--light);
    opacity: 1;
}

.currency-display {
    position: absolute;
    right: 1rem;
    color: var(--gray);
    font-weight: 500;
}

.amount-limits {
    display: flex;
    justify-content: space-between;
    font-size: 0.85rem;
    color: var(--gray);
}

/* Swap Container */
.swap-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: 0 1rem;
    position: relative;
    z-index: 2;
}

.swap-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: var(--white);
    border: 2px solid var(--primary);
    color: var(--primary);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
    margin-bottom: 1rem;
}

.swap-btn:hover {
    background: var(--primary);
    color: var(--white);
    transform: rotate(180deg) scale(1.1);
}

.exchange-rate-display {
    font-size: 0.9rem;
    font-weight: 600;
    color: var(--primary);
    background: rgba(108, 92, 231, 0.1);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    text-align: center;
}

/* Exchange Summary */
.exchange-summary {
    background: rgba(108, 92, 231, 0.05);
    border: 1px dashed rgba(108, 92, 231, 0.3);
    border-radius: var(--border-radius);
    padding: 1.5rem;
}

.summary-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 1rem;
}

.delivery-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.delivery-info i {
    font-size: 1.5rem;
    color: var(--primary);
}

.delivery-info p {
    margin: 0;
    font-size: 0.9rem;
    color: var(--gray);
}

.delivery-info span {
    font-weight: 600;
    color: var(--dark);
}

.btn-continue {
    background: var(--primary);
    color: var(--white);
    border: none;
    border-radius: 8px;
    padding: 1rem 2rem;
    font-weight: 600;
    font-size: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    cursor: pointer;
    transition: var(--transition);
}

.btn-continue:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
}

/* Features Section */
.features-section {
    margin-bottom: 4rem;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
}

.feature-card {
    background: var(--white);
    border-radius: var(--border-radius);
    padding: 2rem;
    box-shadow: var(--shadow);
    transition: var(--transition);
    text-align: center;
}

.feature-card:hover {
    transform: translateY(-5px);
}

.feature-icon {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    background: rgba(108, 92, 231, 0.1);
    color: var(--primary);
    font-size: 1.8rem;
}

.feature-card:nth-child(2) .feature-icon {
    background: rgba(32, 191, 107, 0.1);
    color: #20bf6b;
}

.feature-card:nth-child(3) .feature-icon {
    background: rgba(23, 162, 184, 0.1);
    color: #17a2b8;
}

.feature-card h3 {
    font-size: 1.3rem;
    margin-bottom: 1rem;
    color: var(--dark);
}

.feature-card p {
    color: var(--gray);
    margin-bottom: 1.5rem;
}

.progress-bar {
    height: 6px;
    background: var(--light-gray);
    border-radius: 3px;
    overflow: hidden;
}

.progress {
    height: 100%;
    background: #17a2b8;
    width: 80%;
}

/* Transactions Section */
.transactions-section {
    margin-bottom: 3rem;
}

.transactions-card {
    background: var(--white);
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: var(--shadow);
}

.transactions-header {
    background: var(--primary);
    color: var(--white);
    padding: 1.5rem 2rem;
}

.transactions-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1.3rem;
}

.transactions-body {
    padding: 0;
}

.transactions-table {
    width: 100%;
    border-collapse: collapse;
}

.transactions-table th {
    background: var(--light);
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: var(--gray);
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 0.5px;
}

.transactions-table td {
    padding: 1rem;
    border-top: 1px solid var(--light-gray);
    vertical-align: middle;
}

.transactions-table tr:hover {
    background: rgba(108, 92, 231, 0.03);
}

.status-badge {
    padding: 0.4rem 0.8rem;
    border-radius: 4px;
    font-size: 0.8rem;
    font-weight: 600;
}

.status-badge.completed {
    background: rgba(40, 167, 69, 0.1);
    color: var(--success);
}

.status-badge.pending {
    background: rgba(255, 193, 7, 0.1);
    color: var(--warning);
}

/* Responsive Styles */
@media (max-width: 992px) {
    .hero-title {
        font-size: 2.5rem;
    }
    
    .exchange-cards-container {
        flex-direction: column;
            gap: 0.3rem;

    }
    .form-select{
        padding:0.475rem 1rem;
    }
    .amount-input-group .form-control{
        height:42px;
    }
    
    .swap-container {
        flex-direction: row;
        margin: 0;
    }
    
    .swap-btn {
        margin: 0 1rem 0 0;
    }
}

@media (max-width: 768px) {
    .exchange-main {
        padding: 0.5rem 0;
    }
    
    .hero-title {
        font-size: 2rem;
    }
    .hero-subtitle {
        margin-bottom:-25px !important;
    }
    
    .exchange-widget-container {
        padding: 0.1rem;
    }
    .exchange-summary{
        margin-top:-20px;
    }
    .features-grid{
        gap: 1rem;
    }
    
    .summary-content {
        flex-direction: column;
        text-align: center;
    }
    
    .delivery-info {
        justify-content: center;
    }
    
    .btn-continue {
        width: 100%;
        justify-content: center;
    }
    
    .features-grid {
        grid-template-columns: 1fr;
    }
    
    .transactions-header {
        padding: 1.25rem;
    }
    
    .transactions-table {
        display: block;
        overflow-x: auto;
    }
    
    .transactions-table th,
    .transactions-table td {
        padding: 0.75rem;
    }
}

@media (max-width: 576px) {
    .container {
        padding: 0 10px;
    }
    
    .hero-title {
        font-size: 1.8rem;
    }
    
    .hero-subtitle {
        font-size: 1rem;
    }
    
    .currency-card {
        min-width: 100%;
        padding: 1.25rem;
    }
    
    .exchange-rate-display {
        font-size: 0.8rem;
        padding: 0.4rem 0.8rem;
    }
    
    .transactions-table {
        font-size: 0.85rem;
    }
    
    .status-badge {
        font-size: 0.75rem;
        padding: 0.3rem 0.6rem;
    }
}

/* Animation Classes */
.animate__animated {
    animation-duration: 0.5s;
    animation-fill-mode: both;
}

@keyframes fadeInDown {
    from {
        opacity: 0;
        transform: translate3d(0, -20px, 0);
    }
    to {
        opacity: 1;
        transform: translate3d(0, 0, 0);
    }
}

.animate__fadeInDown {
    animation-name: fadeInDown;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.animate__fadeIn {
    animation-name: fadeIn;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
    20%, 40%, 60%, 80% { transform: translateX(5px); }
}

.animate__shakeX {
    animation-name: shake;
}
</style>

    <footer class="bg-dark text-white mainfooter pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h4 class="text-uppercase mb-4" style="color: #a29bfe;">DUBAIEXCHANGE</h4>
                    <p>The most secure and advanced cryptocurrency exchange platform with 24/7 customer support.</p>
                    <div class="social-icons mt-3">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-telegram-plane"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h5 class="text-uppercase mb-4" style="color: #a29bfe;">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-white text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="aboutus.php" class="text-white text-decoration-none">About Us</a></li>
                        <li class="mb-2"><a href="testimonial.php" class="text-white text-decoration-none">Testimonial</a></li>
                        <li class="mb-2"><a href="rates.php" class="text-white text-decoration-none">Pricing</a></li>
                        <li><a href="contact.php" class="text-white text-decoration-none">Contact</a></li>
                    </ul>
                </div>
              
                <div class="col-md-4 mb-4">
                    <h5 class="text-uppercase mb-4" style="color: #a29bfe;">Newsletter</h5>
                    <p>Subscribe to our newsletter for the latest updates and news.</p>
                    <form class="mb-3" >
                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="Your Email" aria-label="Your Email">
                            <button class="btn btn-primary" type="button" style="background-color: #6c5ce7; border-color: #6c5ce7;">Subscribe</button>
                        </div>
                    </form>
                    <div class="d-flex align-items-center">
                        <i class="fas fa-headset me-2 fs-4" style="color: #a29bfe;"></i>
                        <div>
                            <p class="mb-0">24/7 Customer Support</p>
                            <a href="/cdn-cgi/l/email-protection#73000603031c0107331c1e1d1a160b101b121d14165d101c1e" class="text-white"><span class="__cf_email__" data-cfemail="81f2f4f1f1eef3f5c1e5f4e3e0e8e4f9e2e9e0efe6e4afe2eeec">[email&#160;protected]</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="row align-items-center">
                <div class="col-md-6 mb-3 mb-md-0">
                    <p class="mb-0">&copy; 2025 DubaiExchange. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="termsandconditions.php" class="text-white text-decoration-none me-3">Terms of Service</a>
                    <a href="privacypolicy.php" class="text-white text-decoration-none me-3">Privacy Policy</a>
                    <a href="#" class="text-white text-decoration-none">Cookie Policy</a>
                </div>
            </div>
        </div>
    </footer>

    <style>
        footer {
            background: linear-gradient(135deg, #2d3436, #1e272e);
            position: relative;
            overflow: hidden;
            padding-left: 25px;
            bottom:0;
        }
        
        footer::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(108, 92, 231, 0.1);
            border-radius: 50%;
        }
        
        footer::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 300px;
            height: 300px;
            background: rgba(162, 155, 254, 0.05);
            border-radius: 50%;
        }
        
        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .social-icons a:hover {
            background: #6c5ce7;
            transform: translateY(-3px);
        }
        
        footer ul li a {
            position: relative;
            padding-left: 0;
            transition: all 0.3s ease;
        }
        
        footer ul li a::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 1px;
            background: #a29bfe;
            transition: width 0.3s ease;
        }
        
        footer ul li a:hover {
            color: #a29bfe !important;
            padding-left: 10px;
        }
        
        footer ul li a:hover::before {
            width: 8px;
        }
        
        .input-group input {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
        }
        
        .input-group input:focus {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: none;
            color: white;
            border-color: #a29bfe;
        }
        
        .input-group input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        
        @media (max-width: 768px) {
            footer::before, footer::after {
                display: none;
            }
            
            .col-md-4, .col-md-2 {
                margin-bottom: 2rem;
            }
            .mainfooter{
                padding-bottom:5rem !important;
            }
        }
    </style>
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
        // Animate footer elements on scroll
        document.addEventListener('DOMContentLoaded', function() {
            const footerSections = document.querySelectorAll('footer .col-md-4, footer .col-md-2');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.animation = `fadeInUp 0.5s ease forwards`;
                    }
                });
            }, { threshold: 0.1 });
            
            footerSections.forEach(section => {
                observer.observe(section);
            });
        });
    </script>
</body>
</html>