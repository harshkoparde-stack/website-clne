<base href="/">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>DubaiExchange - Exchange Rates</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <style>
        :root { 
            --primary-color: #6c5ce7;
            --secondary-color: #a29bfe;
            --dark-color: #2d3436;
            --light-color: #f5f6fa;
        }
       
        /* Top Header Styles */
        .top-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 8px 40px;
            color: white;
        }
        
        .availability-text {
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .availability-text i {
    color: #00b894;
    animation: blink 1s step-start infinite;
}

@keyframes blink {
    50% {
        opacity: 0;
    }
}
        
        .auth-buttons .btn {
            border-radius: 20px;
            padding: 6px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .auth-buttons .btn-login {
            background-color: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.4);
            color: white;
        }
        
        .auth-buttons .btn-signup {
            background-color: white;
            color: var(--primary-color);
        }
        
        .auth-buttons .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .auth-buttons .btn:active {
            transform: translateY(0);
        }
        
        .auth-buttons .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }
        
        .auth-buttons .btn:hover::before {
            left: 100%;
        }
        
        /* Main Header Styles */
        .main-header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding-left: 20px;
        }
        
        .logo {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(to right, var(--primary-color) 50%, var(--dark-color) 50%);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            transition: all 0.3s ease;
        }
        
        .logo:hover {
            transform: scale(1.05);
        }
        
        .nav-link {
            color: var(--dark-color);
            font-weight: 500;
            position: relative;
            padding: 8px 15px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: var(--primary-color);
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background-color: var(--primary-color);
            transition: width 0.3s ease;
        }
        
        .nav-link:hover::after {
            width: 70%;
        }
        
        /* User Dropdown Styles */
        .user-dropdown .dropdown-toggle {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--dark-color);
            font-weight: 500;
        }
        
        .user-dropdown .dropdown-toggle::after {
            margin-left: 8px;
        }
        
        .user-dropdown .dropdown-menu {
            border: none;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .user-dropdown .dropdown-item {
            padding: 10px 15px;
            transition: all 0.2s ease;
        }
        
        .user-dropdown .dropdown-item:hover {
            background-color: var(--secondary-color);
            color: white;
            padding-left: 20px;
        }
        
        /* Mobile Menu */
        .navbar-toggler {
            border: none;
            padding: 8px;
        }
        
        .navbar-toggler:focus {
            box-shadow: none;
        }
        
        .navbar-toggler-icon {
            background-image: none;
            position: relative;
            width: 24px;
            height: 2px;
            background-color: var(--dark-color);
            transition: all 0.3s ease;
        }
        
        .navbar-toggler-icon::before,
        .navbar-toggler-icon::after {
            content: '';
            position: absolute;
            width: 24px;
            height: 2px;
            background-color: var(--dark-color);
            left: 0;
            transition: all 0.3s ease;
        }
        
        .navbar-toggler-icon::before {
            transform: translateY(-8px);
        }
        
        .navbar-toggler-icon::after {
            transform: translateY(8px);
        }
        
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon {
            background-color: transparent;
        }
        
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon::before {
            transform: rotate(45deg);
        }
        
        .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon::after {
            transform: rotate(-45deg);
        }
        
        /* Mobile Auth Buttons */
        .mobile-auth-buttons {
            display: none;
            padding: 15px 0;
        }
        
        .mobile-auth-buttons .btn {
            border-radius: 20px;
            padding: 8px 20px;
            font-weight: 500;
            margin: 5px 0;
            width: auto;
            display: inline-block;
        }
        
        .mobile-auth-buttons .btn-login {
            background-color: rgba(108, 92, 231, 0.2);
            border: 1px solid rgba(108, 92, 231, 0.4);
            color: var(--primary-color);
        }
        
        .mobile-auth-buttons .btn-signup {
            background-color: var(--primary-color);
            color: white;
        }
        
        .mobile-auth-container {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        /* Mobile User Dropdown */
        .mobile-user-dropdown .dropdown-toggle {
            width: 100%;
            text-align: left;
            background-color: var(--light-color);
            border: none;
            color: var(--dark-color);
            padding: 10px 15px;
            border-radius: 8px;
        }
        
        /* Animations */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .auth-buttons {
                display: none;
            }
            
            .mobile-auth-buttons {
                display: block;
            }
            
            .availability-text {
                padding-top: 12px;
            }
            
            .nav-item {
                margin: 5px 0;
            }
            
            .navbar-nav {
                padding-bottom: 15px;
                border-bottom: 1px solid rgba(0,0,0,0.1);
            }
            .availability-text{
                padding:4px !important;
            }
            .navbar-brand{
                font-size:1.5rem !important;
            }
        }
    </style>
</head>
<body>
    <!-- Top Header Section -->
    <div class="top-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="availability-text animate__animated animate__fadeIn">
                        <i class="fas fa-circle"></i> 24/7 Available
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="auth-buttons">
                                                    <a href="auth/login.php" class="btn btn-login me-2 animate__animated animate__fadeInRight">Login</a>
                            <a href="auth/signup.php" class="btn btn-signup animate__animated animate__fadeInRight">Sign Up</a>
                                            </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Header Section -->
    <header class="main-header">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand logo" href="index.php">DUBAIEXCHANGE</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <div class="mobile-auth-buttons">
                                                    <div class="mobile-auth-container">
                                <a href="auth/login.php" class="btn btn-login animate__animated animate__fadeInRight">Login</a>
                                                            <a href="auth/signup.php" class="btn btn-signup animate__animated animate__fadeInRight">Sign Up</a>

                            </div>
                                            </div>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Exchange</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="deposit.php">Deposit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rates.php">Rates</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonial.php">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="news.php">News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                    
                    <!-- Mobile Auth Buttons -->
                    
                </div>
            </nav>
        </div>
    </header>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation to nav items on page load
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach((item, index) => {
                item.style.animation = `fadeInDown 0.5s ease forwards ${index * 0.1}s`;
            });
            
            // Add ripple effect to buttons
            const buttons = document.querySelectorAll('.btn');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const x = e.clientX - e.target.getBoundingClientRect().left;
                    const y = e.clientY - e.target.getBoundingClientRect().top;
                    
                    const ripple = document.createElement('span');
                    ripple.className = 'ripple';
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    
                    this.appendChild(ripple);
                    
                    setTimeout(() => {
                        ripple.remove();
                    }, 1000);
                });
            });
        });
    </script>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>WhatsApp Button</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .whatsapp-float {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: rgba(201, 255, 200, 0.3);
            color: #25d366;
            border-radius: 30px;
            padding: 8px 15px;
            font-size: 16px;
            box-shadow: 2px 2px 8px rgba(0,0,0,0.3);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: transform 0.2s ease-in-out, background-color 0.3s;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-weight: bold;
        }

        .whatsapp-float i {
            font-size: 30px;
        }

        .whatsapp-float:hover {
            background-color: rgba(37, 211, 102, 0.3);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <!-- WhatsApp Floating Button -->
    <a href="https://wa.me/+918516885685?text=Hello+i+Need+USDT" 
       target="_blank" 
       class="whatsapp-float" 
       id="whatsappButton">
        <i class="fab fa-whatsapp"></i>
        <span class="help-text">Need Help?</span>
    </a>

    <script>
    // Function to update the WhatsApp number every minute
    function updateWhatsAppNumber() {
        fetch('get_whatsapp_number.php')
            .then(response => response.json())
            .then(data => {
                if (data.number) {
                    const whatsappButton = document.getElementById('whatsappButton');
                    whatsappButton.href = `https://wa.me/${data.number}?text=${encodeURIComponent('Hello i Need USDT')}`;
                }
            })
            .catch(error => console.error('Error fetching WhatsApp number:', error));
    }

    // Update immediately and then every minute
    updateWhatsAppNumber();
    setInterval(updateWhatsAppNumber, 60000); // 60,000 ms = 1 minute
    </script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"9cb5e453abb04bcaa0059d78bd938d1d","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>

<div class="container py-5">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-lg">
                <div class="card-header" style="background-color: #6c5ce7; color: white;">
                    <h3 class="mb-0">Current Exchange Rates</h3>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead style="background-color: #f5f6fa;">
                                <tr>
                                    <th>Currency Pair</th>
                                    <th class="text-end">Rate</th>
                                    <th class="text-end">Min Amount</th>
                                    <th class="text-end">Max Amount</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td><strong>INR</strong> → <strong>USDT</strong></td><td class="text-end">1 INR = 87.00 USDT</td><td class="text-end">2,175.00 INR</td><td class="text-end">10,000,000.00 INR</td><td class="text-center"><a href="index.php" class="btn btn-sm btn-primary" style="background-color: #6c5ce7; border: none;">Exchange</a></td></tr><tr><td><strong>USDT</strong> → <strong>INR</strong></td><td class="text-end">1 USDT = 90.0000000 INR</td><td class="text-end">35.00 USDT</td><td class="text-end">20,000.00 USDT</td><td class="text-center"><a href="index.php" class="btn btn-sm btn-primary" style="background-color: #6c5ce7; border: none;">Exchange</a></td></tr>                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer text-muted">
                    Last updated: 2025-12-18 16:40:09                    <div class="float-end">
                        <small>24/7 Exchange Available</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.table th {
    border-top: none;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 0.9rem;
    letter-spacing: 0.5px;
}

.table td {
    vertical-align: middle;
}

.table-hover tbody tr:hover {
    background-color: rgba(108, 92, 231, 0.05);
}

.card-footer {
    background-color: rgba(0, 0, 0, 0.02);
    font-size: 0.85rem;
}

@media (max-width: 768px) {
    .table th, .table td {
        font-size: 0.8rem;
        padding: 0.5rem;
    }
    
    .table img {
        width: 60px !important;
    }
    
    .btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.8rem;
    }
}
</style>

    <footer class="bg-dark text-white mainfooter pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h4 class="text-uppercase mb-4" style="color: #a29bfe;">DUBAIEXCHANGE</h4>
                    <p>The most secure and advanced cryptocurrency exchange platform with 24/7 customer support.</p>
                    <div class="social-icons mt-3">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-telegram-plane"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h5 class="text-uppercase mb-4" style="color: #a29bfe;">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-white text-decoration-none">Home</a></li>
                        <li class="mb-2"><a href="aboutus.php" class="text-white text-decoration-none">About Us</a></li>
                        <li class="mb-2"><a href="testimonial.php" class="text-white text-decoration-none">Testimonial</a></li>
                        <li class="mb-2"><a href="rates.php" class="text-white text-decoration-none">Pricing</a></li>
                        <li><a href="contact.php" class="text-white text-decoration-none">Contact</a></li>
                    </ul>
                </div>
              
                <div class="col-md-4 mb-4">
                    <h5 class="text-uppercase mb-4" style="color: #a29bfe;">Newsletter</h5>
                    <p>Subscribe to our newsletter for the latest updates and news.</p>
                    <form class="mb-3" >
                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="Your Email" aria-label="Your Email">
                            <button class="btn btn-primary" type="button" style="background-color: #6c5ce7; border-color: #6c5ce7;">Subscribe</button>
                        </div>
                    </form>
                    <div class="d-flex align-items-center">
                        <i class="fas fa-headset me-2 fs-4" style="color: #a29bfe;"></i>
                        <div>
                            <p class="mb-0">24/7 Customer Support</p>
                            <a href="/cdn-cgi/l/email-protection#7e0d0b0e0e110c0a3e111310171b061d161f10191b501d1113" class="text-white"><span class="__cf_email__" data-cfemail="6b181e1b1b04191f2b0f1e090a020e1308030a050c0e45080406">[email&#160;protected]</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="row align-items-center">
                <div class="col-md-6 mb-3 mb-md-0">
                    <p class="mb-0">&copy; 2025 DubaiExchange. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="termsandconditions.php" class="text-white text-decoration-none me-3">Terms of Service</a>
                    <a href="privacypolicy.php" class="text-white text-decoration-none me-3">Privacy Policy</a>
                    <a href="#" class="text-white text-decoration-none">Cookie Policy</a>
                </div>
            </div>
        </div>
    </footer>

    <style>
        footer {
            background: linear-gradient(135deg, #2d3436, #1e272e);
            position: relative;
            overflow: hidden;
            padding-left: 25px;
            bottom:0;
        }
        
        footer::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(108, 92, 231, 0.1);
            border-radius: 50%;
        }
        
        footer::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 300px;
            height: 300px;
            background: rgba(162, 155, 254, 0.05);
            border-radius: 50%;
        }
        
        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .social-icons a:hover {
            background: #6c5ce7;
            transform: translateY(-3px);
        }
        
        footer ul li a {
            position: relative;
            padding-left: 0;
            transition: all 0.3s ease;
        }
        
        footer ul li a::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 1px;
            background: #a29bfe;
            transition: width 0.3s ease;
        }
        
        footer ul li a:hover {
            color: #a29bfe !important;
            padding-left: 10px;
        }
        
        footer ul li a:hover::before {
            width: 8px;
        }
        
        .input-group input {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
        }
        
        .input-group input:focus {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: none;
            color: white;
            border-color: #a29bfe;
        }
        
        .input-group input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        
        @media (max-width: 768px) {
            footer::before, footer::after {
                display: none;
            }
            
            .col-md-4, .col-md-2 {
                margin-bottom: 2rem;
            }
            .mainfooter{
                padding-bottom:5rem !important;
            }
        }
    </style>
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
        // Animate footer elements on scroll
        document.addEventListener('DOMContentLoaded', function() {
            const footerSections = document.querySelectorAll('footer .col-md-4, footer .col-md-2');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.animation = `fadeInUp 0.5s ease forwards`;
                    }
                });
            }, { threshold: 0.1 });
            
            footerSections.forEach(section => {
                observer.observe(section);
            });
        });
    </script>
</body>
</html>